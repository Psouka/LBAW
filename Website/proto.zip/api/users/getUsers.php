<?php
    include_once('../../config/init.php');
    include_once ($BASE_DIR . 'database/users.php');

    $users = getUsers ();

    echo json_encode ($users);
?>